import TableBook from "@/components/admin/book/table.book";

const ManageBookPage = () => {
    return (
        <div>
            <TableBook />
        </div>
    )
}

export default ManageBookPage;
